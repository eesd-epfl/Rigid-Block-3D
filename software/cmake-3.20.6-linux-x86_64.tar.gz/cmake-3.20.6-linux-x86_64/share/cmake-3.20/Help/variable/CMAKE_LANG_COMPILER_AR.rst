CMAKE_<LANG>_COMPILER_AR
------------------------

.. versionadded:: 3.9

A wrapper around ``ar`` adding the appropriate ``--plugin`` option for the
compiler.

See also :variable:`CMAKE_AR`.
