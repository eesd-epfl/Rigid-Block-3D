CMAKE_MODULE_LINKER_FLAGS
-------------------------

Linker flags to be used to create modules.

These flags will be used by the linker when creating a module.
