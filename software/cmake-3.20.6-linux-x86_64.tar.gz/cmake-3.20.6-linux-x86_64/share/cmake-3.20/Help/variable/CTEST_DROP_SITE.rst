CTEST_DROP_SITE
---------------

.. versionadded:: 3.1

Specify the CTest ``DropSite`` setting
in a :manual:`ctest(1)` dashboard client script.
