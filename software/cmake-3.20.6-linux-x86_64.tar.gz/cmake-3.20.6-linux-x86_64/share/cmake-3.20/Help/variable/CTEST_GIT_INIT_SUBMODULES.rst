CTEST_GIT_INIT_SUBMODULES
-------------------------

.. versionadded:: 3.6

Specify the CTest ``GITInitSubmodules`` setting
in a :manual:`ctest(1)` dashboard client script.
