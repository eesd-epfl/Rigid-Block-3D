CTEST_MEMORYCHECK_COMMAND
-------------------------

.. versionadded:: 3.1

Specify the CTest ``MemoryCheckCommand`` setting
in a :manual:`ctest(1)` dashboard client script.
