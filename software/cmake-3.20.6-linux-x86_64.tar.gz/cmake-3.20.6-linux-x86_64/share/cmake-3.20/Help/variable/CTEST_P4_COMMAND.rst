CTEST_P4_COMMAND
----------------

.. versionadded:: 3.1

Specify the CTest ``P4Command`` setting
in a :manual:`ctest(1)` dashboard client script.
