GHS-MULTI
---------

.. versionadded:: 3.3

``True`` when using :generator:`Green Hills MULTI` generator.
