PROJECT_DESCRIPTION
-------------------

.. versionadded:: 3.9

Short project description given to the project command.

This is the description given to the most recently called :command:`project`
command in the current directory scope or above.  To obtain the description
of the top level project, see the :variable:`CMAKE_PROJECT_DESCRIPTION`
variable.
