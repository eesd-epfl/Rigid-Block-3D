WINCE
-----

.. versionadded:: 3.1

True when the :variable:`CMAKE_SYSTEM_NAME` variable is set
to ``WindowsCE``.
